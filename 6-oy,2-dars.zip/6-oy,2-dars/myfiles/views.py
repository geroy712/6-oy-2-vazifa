from django.shortcuts import render

# Create your views here.

def home(malumot):
    return render(malumot,'index.html')

def iron_man(malumot):
    return render(malumot,'2-view-uchun.html')

def view3(malumot):
    return render(malumot,'3-view-uchun.html')

def view4(malumot):
    return render(malumot,'4-view-uchun.html')

def view5(malumot):
    return render(malumot,'5-view-uchun.html')

def view6(malumot):
    return render(malumot,'6-view-uchun.html')

def view7(malumot):
    return render(malumot,'7-view-uchun.html')

def view8(malumot):
    return render(malumot,'8-view-uchun.html')

def view9(malumot):
    return render(malumot,'9-view-uchun.html')

def view10(malumot):
    return render(malumot,'10-view-uchun.html')
